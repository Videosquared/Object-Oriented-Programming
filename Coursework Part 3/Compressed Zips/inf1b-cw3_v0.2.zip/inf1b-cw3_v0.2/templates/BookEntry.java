/**
 * Immutable class encapsulating data for a single book entry.
 */
public class BookEntry {
    // TODO Implement me
}
