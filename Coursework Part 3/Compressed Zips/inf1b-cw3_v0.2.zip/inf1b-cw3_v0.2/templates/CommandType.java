/** All available command types. */
public enum CommandType {
    HELP,
    EXIT,
    ADD,
    SEARCH,
    LIST,
    REMOVE,
    GROUP
}
